package com.yash.costcalculator.util;

public class ApiEndPoints {

	public static final String PARCEL = "/parcel";
	public static final String CALCULATE_COST = "/calculate-cost";
}
