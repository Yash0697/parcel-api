package com.yash.costcalculator.service.strategy;

public interface CostStrategy {
	
	Double calculateCost();
}
