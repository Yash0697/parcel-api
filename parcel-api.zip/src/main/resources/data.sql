INSERT INTO STRATEGY_PARAMS(ID, Strategy, Volume, Weight) values(1,'RejectParcelStrategy',-10000000000,50)
INSERT INTO STRATEGY_PARAMS(ID, Strategy, Volume, Weight) values(2,'HeavyParcelStrategy',-10000000000,10)
INSERT INTO STRATEGY_PARAMS(ID, Strategy, Volume, Weight) values(3,'SmallParcelStrategy',1500,10000000000)
INSERT INTO STRATEGY_PARAMS(ID, Strategy, Volume, Weight) values(4,'MediumParcelStrategy',2500,10000000000)